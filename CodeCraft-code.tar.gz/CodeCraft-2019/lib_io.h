#ifndef __LIB_IO_H__
#define __LIB_IO_H__

#define MAX_INFO_NUM    50
#define MAX_DATA_NUM    50000


#endif

