#!/bin/bash
sh build.sh
cd bin
#./CodeCraft-2019 ../config/car.txt ../config/road.txt ../config/cross.txt ../config/answer.txt
./CodeCraft-2019 ../config_10/car.txt ../config_10/road.txt ../config_10/cross.txt ../config_10/answer.txt

